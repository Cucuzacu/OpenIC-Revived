package org.josl.openic;

public class IC13 {

    private IC13() {}

    public static boolean icIsKeyPressed(int keyCode) {
        return IC.isKeyPressed(keyCode);
    }

}
