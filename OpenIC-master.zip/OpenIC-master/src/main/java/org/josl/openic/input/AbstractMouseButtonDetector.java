package org.josl.openic.input;

public abstract class AbstractMouseButtonDetector extends Mouse implements MouseButtonDetector {
}
