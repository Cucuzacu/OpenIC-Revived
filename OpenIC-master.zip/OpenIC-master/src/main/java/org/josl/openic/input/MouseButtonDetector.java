package org.josl.openic.input;

public interface MouseButtonDetector {

    boolean isButtonPressed(int button);

}
